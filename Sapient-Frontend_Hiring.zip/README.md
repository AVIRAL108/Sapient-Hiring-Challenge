This is Hiring Project for Publicis Sapient for UI Engineer Role

### Steps to run the Application
1) unzip the folder
2) set the CLI to the extracted path of the folder.
3) write npm install or Yarn install to install the dependencies. 
4) run yarn run dev or npm run dev command to run react app. After few seconds, react app will run on http://localhost:3006 and go and hit this url.